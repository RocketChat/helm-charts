{{/* vim: set filetype=helm: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "rocketchat.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Return the image registry prefix.
When global.imageRegistry is set, returns "registry/" to prepend to image names.
Usage: {{ include "rocketchat.imageRegistry" . }}{{ .Values.image.repository }}
*/}}
{{- define "rocketchat.imageRegistry" -}}
{{- if .Values.global.imageRegistry -}}
{{- printf "%s/" .Values.global.imageRegistry -}}
{{- end -}}
{{- end -}}

{{/*
Return the full image reference with optional registry override.
Usage: {{ include "rocketchat.image" (dict "repository" .Values.image.repository "tag" .Values.image.tag "appVersion" .Chart.AppVersion "global" .Values.global) }}
*/}}
{{- define "rocketchat.image" -}}
{{- $registry := "" -}}
{{- if .global.imageRegistry -}}
{{- $registry = printf "%s/" .global.imageRegistry -}}
{{- end -}}
{{- $tag := .tag | default .appVersion -}}
{{- printf "%s%s:%s" $registry .repository $tag -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "rocketchat.fullname" -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "rocketchat.mongodb.fullname" -}}
{{- printf "%s-%s-headless" .Release.Name "mongodb" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "rocketchat.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "rocketchat.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "rocketchat.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Return the apiVersion of deployment.
*/}}
{{- define "deployment.apiVersion" -}}
{{- if semverCompare "<1.14-0" .Capabilities.KubeVersion.GitVersion -}}
{{- print "extensions/v1beta1" -}}
{{- else if semverCompare ">=1.14-0" .Capabilities.KubeVersion.GitVersion -}}
{{- print "apps/v1" -}}
{{- end -}}
{{- end -}}

{{/*
Renders a value that contains template. 
Note: This function was lent from Bitnami Common Library Chart (cf. 
https://github.com/bitnami/charts/blob/master/bitnami/common/templates/_tplvalues.tpl)
Usage:
{{ include "common.tplvalues.render" ( dict "value" .Values.path.to.the.Value "context" $) }}
*/}}
{{- define "common.tplvalues.render" -}}
    {{- if typeIs "string" .value }}
        {{- tpl .value .context }}
    {{- else }}
        {{- tpl (.value | toYaml) .context }}
    {{- end }}
{{- end -}}

{{/*Generate the MONGO_URL*/}}
{{- define "rocketchat.mongodb.url" }}
    {{- if .Values.externalMongodbUrl }}
        {{- print .Values.externalMongodbUrl }}
    {{- else if .Values.mongodb.enabled }}
        {{- $service := include "rocketchat.mongodb.fullname" . }}
        {{- $user := first .Values.mongodb.auth.usernames | default "rocketchat" }}
        {{- $password := first .Values.mongodb.auth.passwords | default "changeme" }}
        {{- $database := first .Values.mongodb.auth.databases | default "rocketchat" }}
        {{- $port := .Values.mongodb.service.ports.mongodb }}
        {{- $rs := .Values.mongodb.replicaSetName }}
        {{- printf "mongodb://%s:%s@%s:%0.f/%s?replicaSet=%s" $user $password $service $port $database $rs }}
    {{- else }}
        {{- fail "mongodb.enabled is false but externalMongodbUrl is not set" }}
    {{- end }}
{{- end }}

{{/* TODO: fail if types of the following are not what is expected instead of silently ignoring */}}

{{/* Get correct tolerations */}}
{{- define "rocketchat.tolerations" -}}
{{- $name := .name -}}
{{- $tolerations := list -}}
{{- with .context }}
{{- if eq $name "meteor" }}
{{ $tolerations = .Values.tolerations }}
{{- else }}
{{ $tolerations = get (get .Values.microservices $name) "tolerations" }}
{{- end }}
{{- if (and (kindIs "slice" $tolerations) (gt (len $tolerations) 0)) }}
{{- toYaml $tolerations }}
{{- else if (and (kindIs "slice" .Values.global.tolerations) (gt (len .Values.global.tolerations) 0)) }}
{{- toYaml .Values.global.tolerations }}
{{- end }}
{{- end }}
{{- end -}}

{{/* Get correct annotations */}}
{{- define "rocketchat.annotations" -}}
{{- $name := .name -}}
{{- $annotations := dict -}}
{{- with .context }}
{{- if eq $name "meteor" }}
{{ $annotations = .Values.podAnnotations}}
{{- else }}
{{ $annotations = get (get .Values.microservices $name) "annotations" }}
{{- end }}
{{- if (and (kindIs "map" $annotations) (gt (len $annotations) 0)) }}
{{- toYaml $annotations}}
{{- else if (and (kindIs "map" .Values.global.annotations) (gt (keys .Values.global.annotations | len) 0)) }}
{{- toYaml .Values.global.annotations}}
{{- end }}
{{- end }}
{{- end -}}

{{/* Get correct nodeSelector */}}
{{- define "rocketchat.nodeSelector" -}}
{{- $name := .name -}}
{{- $nodeSelector := dict -}}
{{- with .context }}
{{- if eq $name "meteor" }}
{{ $nodeSelector = .Values.nodeSelector }}
{{- else }}
{{ $nodeSelector = get (get .Values.microservices $name) "nodeSelector" }}
{{- end }}
{{- if (and (kindIs "map" $nodeSelector) (gt (len $nodeSelector) 0)) }}
{{- toYaml $nodeSelector | indent 2 }}
{{- else if (and (kindIs "map" .Values.global.nodeSelector) (gt (keys .Values.global.nodeSelector | len) 0)) }}
{{- toYaml .Values.global.nodeSelector | indent 2 }}
{{- end }}
{{- end }}
{{- end -}}

{{/* Get correct nodeAffinity */}}
{{- define "rocketchat.nodeAffinity" -}}
{{- $name := .name -}}
{{- $nodeAffinity := dict -}}
{{- with .context }}
{{- if eq $name "meteor" }}
{{ $nodeAffinity = .Values.affinity }}
{{- else }}
{{ $nodeAffinity = get (get .Values.microservices $name) "affinity" }}
{{- end }}
{{- if (and (kindIs "map" $nodeAffinity) (gt (len $nodeAffinity) 0)) }}
{{- toYaml $nodeAffinity | indent 8 }}
{{- else if (and (kindIs "map" .Values.global.affinity) (gt (keys .Values.global.affinity | len) 0)) }}
{{- toYaml .Values.global.affinity | indent 8 }}
{{- end }}
{{- end }}
{{- end -}}


{{/* Nats */}}
{{- define "rocketchat.transporter.connectionString" -}}
{{/*
One of the following must be true to set the TRANSPORTER environment variable:
1. If running microservices, and nats.enabled is not set, then we have deployed it
2. If nats.enabled is true, then we have deployed it
3. If nats.existingSecret is set, then we are using an external NATS server
*/}}
{{- if
    or
        (and (hasKey .Values.microservices "enabled") (.Values.microservices.enabled) (not (hasKey .Values.nats "enabled")))
        (and (hasKey .Values.nats "enabled") (.Values.nats.enabled))
        (and (hasKey .Values.nats "existingSecret") (not (empty .Values.nats.existingSecret)))
-}}
{{- if (hasKey .Values.nats "existingSecret") }}
- name: TRANSPORTER
  valueFrom:
    secretKeyRef:
      name: {{ .Values.nats.existingSecret.name }}
      key: {{ .Values.nats.existingSecret.key }}
{{- else }}
{{/* Determine protocol to use */}}
{{- $natsProtocol := "monolith+nats" -}}
{{- if and (hasKey .Values.microservices "enabled") (.Values.microservices.enabled) -}}
{{- $natsProtocol = "nats" -}}
{{- end -}}
- name: TRANSPORTER
  value: "{{ $natsProtocol }}://{{ .Release.Name }}-nats:4222"

{{- end -}}
{{- end -}} {{/* End if Nats enabled */}}
{{- end -}} {{/* rocketchat.transporter.connectionString */}}

{{/* This is needed to avoid breaking when people use --reuse-values
    and previously didn't had the path microservices.streamHub.enabled,
    but always true to version bellow 7.7
*/}}
{{- define "rocketchat.streamHub.enabled" -}}
{{- if (hasKey .Values.microservices.streamHub "enabled") -}}
{{- .Values.microservices.streamHub.enabled -}}
{{- else if semverCompare "<=7.7.0" (.Values.image.tag | default .Chart.AppVersion) -}}
true
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/*
Render pod hostAliases from .Values.extraHosts, a list of {hostname: string, ip: string}.
Entries sharing an ip are grouped into a single hostAlias.
*/}}
{{- define "rocketchat.hostAliases" -}}
{{- $byIp := dict -}}
{{- $ips := list -}}
{{- range $i, $h := .Values.extraHosts -}}
{{- if not (kindIs "map" $h) -}}
{{- fail (printf "extraHosts[%d] must be an object of the form {hostname: string, ip: string}" $i) -}}
{{- end -}}
{{- if not (and (kindIs "string" $h.hostname) $h.hostname) -}}
{{- fail (printf "extraHosts[%d].hostname must be a non-empty string" $i) -}}
{{- end -}}
{{- if not (and (kindIs "string" $h.ip) $h.ip) -}}
{{- fail (printf "extraHosts[%d].ip must be a non-empty string" $i) -}}
{{- end -}}
{{- if not (hasKey $byIp $h.ip) -}}
{{- $ips = append $ips $h.ip -}}
{{- $_ := set $byIp $h.ip list -}}
{{- end -}}
{{- $_ := set $byIp $h.ip (append (get $byIp $h.ip) $h.hostname) -}}
{{- end -}}
{{- if $ips }}
hostAliases:
{{- range $ips }}
  - ip: {{ . | quote }}
    hostnames:
    {{- range get $byIp . }}
      - {{ . | quote }}
    {{- end }}
{{- end }}
{{- end }}
{{- end -}}
